local ADDON, Addon = ...
local Mod = Addon:NewModule('Schedule')

local rowCount = 4
local PARTY_PREFIX = 'AK_KEYS'
local REQUEST = 'R'
local RESPONSE = 'K'
local msPerWeek = 7 * 24 * 60 * 60

-- Rotation data used by the addon.  The week index is selected from the fixed
-- reset epoch below, so the schedule is available even when no key is in bags.
-- The existing Tauri/Legion affix IDs are intentionally retained here.
-- Rotation harvested from napnapnapnap/mythicpl.us (gh-pages/index.html).
-- The website currently has an 8-week table.
-- Local Angry Keystones IDs: 1 Overflowing, 2 Skittish, 3 Volcanic,
-- 4 Necrotic, 5 Teeming, 6 Raging, 7 Bolstering, 8 Sanguine,
-- 9 Tyrannical, 10 Fortified.
local affixSchedule = {
	-- wk1: Raging / Necrotic / Fortified
	{ 6, 4, 10 },
	-- wk2: Bolstering / Overflowing / Tyrannical
	{ 7, 1, 9 },
	-- wk3: Sanguine / Volcanic / Fortified
	{ 8, 3, 10 },
	-- wk4: Teeming / Necrotic / Tyrannical
	{ 5, 4, 9 },
	-- wk5: Raging / Volcanic / Tyrannical
	{ 6, 3, 9 },
	-- wk6: Bolstering / Skittish / Fortified
	{ 7, 2, 10 },
	-- wk7: Sanguine / Overflowing / Tyrannical
	{ 8, 1, 9 },
	-- wk8: Teeming / Skittish / Fortified
	{ 5, 2, 10 },
}

-- Same fixed-epoch idea as the mythic.pl rotation logic supplied with the task.
-- Keep this as the most recent known weekly reset anchor.
local epoch = 1789542000 -- 2026-09-16 07:00:00 UTC

local currentWeek
local requestKeystoneCheck
local partyKeys = {}

local function GetRotationWeek()
	local weeksDiff = math.floor((time() - epoch) / msPerWeek)
	-- Match getaffixes.js exactly:
	-- index = (1 + (weeksDiff % 8) + 8) % 8
	-- Lua table indices are 1-based, so add one after calculating the 0-based index.
	local index = (1 + (weeksDiff % #affixSchedule) + #affixSchedule) % #affixSchedule
	return index + 1
end

local function GetPlayerName()
	return UnitName('player') or 'player'
end

local function FindBestKeystone()
	local best
	for container = BACKPACK_CONTAINER, NUM_BAG_SLOTS do
		local slots = GetContainerNumSlots(container)
		for slot = 1, slots do
			local _, _, _, _, _, _, slotLink = GetContainerItemInfo(container, slot)
			if slotLink then
				local itemString = slotLink:match('|Hkeystone:([0-9:]+)|h')
				if itemString then
					local info = { strsplit(':', itemString) }
					local mapID = tonumber(info[1])
					local level = tonumber(info[2])
					if mapID and level and (not best or level > best.level) then
						best = { mapID = mapID, level = level }
					end
				end
			end
		end
	end
	return best
end

local function GetKeystoneText(key)
	if not key then
		return 'No keystone'
	end
	local mapName = C_ChallengeMode.GetMapInfo(key.mapID)
	if not mapName then
		mapName = 'Unknown dungeon'
	end
	return format('+%d %s', key.level, mapName)
end

local function SendOwnKeystone()
	local key = FindBestKeystone()
	local mapID = key and key.mapID or 0
	local level = key and key.level or 0
	SendAddonMessage(PARTY_PREFIX, RESPONSE .. ':' .. mapID .. ':' .. level, 'PARTY')
end

local function RequestPartyKeys()
	if not IsInGroup() then
		return
	end
	partyKeys = {}
	SendAddonMessage(PARTY_PREFIX, REQUEST, 'PARTY')
	SendOwnKeystone()
end

local function SetPartyRow(row, name, class, key)
	row.Text:SetText(name or '')

	local r, g, b = 1, 1, 1
	if class then
		r, g, b = GetClassColor(class)
	end
	row.Text:SetTextColor(r or 1, g or 1, b or 1)

	if key then
		if key.mapID and key.mapID > 0 and key.level and key.level > 0 then
			row.Key:SetText(GetKeystoneText(key))
			row.Key:SetTextColor(1, 0.82, 0)
		else
			row.Key:SetText('No keystone')
			row.Key:SetTextColor(0.7, 0.7, 0.7)
		end
	else
		row.Key:SetText('Waiting...')
		row.Key:SetTextColor(0.7, 0.7, 0.7)
	end
end

local function UpdatePartyRows()
	if not Mod.PartyFrame then return end

	local shown = 0

	-- Our own character is always the first row.
	do
		local row = Mod.PartyFrame.Entries[1]
		local name = UnitName('player') or 'You'
		local _, class = UnitClass('player')
		local key = FindBestKeystone()

		SetPartyRow(row, name, class, key or { mapID = 0, level = 0 })
		row:Show()
		shown = shown + 1
	end

	-- Party members follow our own character.
	for i = 1, 4 do
		local unit = 'party' .. i
		local row = Mod.PartyFrame.Entries[i + 1]

		if UnitExists(unit) then
			shown = shown + 1

			local name = GetUnitName(unit, true) or GetUnitName(unit) or ('Party ' .. i)
			local shortName = name:match('^([^%-]+)') or name
			local _, class = UnitClass(unit)
			local key = partyKeys[name] or partyKeys[shortName]

			SetPartyRow(row, shortName, class, key)
			row:Show()
		else
			row:Hide()
		end
	end

	Mod.PartyFrame.Empty:SetShown(shown == 1)
end

local function UpdateAffixes()
	if requestKeystoneCheck then
		Mod:CheckInventoryKeystone()
	end

	if not currentWeek then
		currentWeek = GetRotationWeek()
	end

	for i = 1, rowCount do
		local entry = Mod.Frame.Entries[i]
		entry:Show()

		local scheduleWeek = (currentWeek + i - 3) % (#affixSchedule) + 1
		local affixes = affixSchedule[scheduleWeek]
		for j = 1, 3 do
			local affix = entry.Affixes[j]
			if affixes[j] then
				affix:SetUp(affixes[j])
				affix:Show()
			else
				affix:Hide()
			end
		end
	end
	Mod.Frame.Label:Hide()
	UpdatePartyRows()
end

local function makeAffix(parent)
	local frame = CreateFrame('Frame', nil, parent)
	frame:SetSize(16, 16)

	local border = frame:CreateTexture(nil, 'OVERLAY')
	border:SetAllPoints()
	border:SetAtlas('ChallengeMode-AffixRing-Sm')
	frame.Border = border

	local portrait = frame:CreateTexture(nil, 'ARTWORK')
	portrait:SetSize(14, 14)
	portrait:SetPoint('CENTER', border)
	frame.Portrait = portrait

	frame.SetUp = ScenarioChallengeModeAffixMixin.SetUp
	frame:SetScript('OnEnter', ScenarioChallengeModeAffixMixin.OnEnter)
	frame:SetScript('OnLeave', GameTooltip_Hide)

	return frame
end

local function makePanel(parent, width, titleText)
	local frame = CreateFrame('Frame', nil, parent)
	frame:SetSize(width, 110)

	local bg = frame:CreateTexture(nil, 'BACKGROUND')
	bg:SetAllPoints()
	bg:SetAtlas('ChallengeMode-guild-background')
	bg:SetAlpha(0.4)

	local title = frame:CreateFontString(nil, 'ARTWORK', 'GameFontNormalMed2')
	title:SetText(titleText)
	title:SetPoint('TOPLEFT', 15, -7)
	frame.Title = title

	local line = frame:CreateTexture(nil, 'ARTWORK')
	line:SetSize(width - 14, 9)
	line:SetAtlas('ChallengeMode-RankLineDivider', false)
	line:SetPoint('TOP', 0, -20)
	frame.Line = line

	return frame
end

function Mod:Blizzard_ChallengesUI()
	ChallengesFrame.GuildBest:ClearAllPoints()
	ChallengesFrame.GuildBest:SetPoint('TOPLEFT', ChallengesFrame.WeeklyBest.Child.Star, 'BOTTOMRIGHT', 9, 30)

	-- One anchored container: no dragging, no standalone toggle window.
	local container = CreateFrame('Frame', nil, ChallengesFrame)
	container:SetSize(430, 128)
	container:SetPoint('TOP', ChallengesFrame.WeeklyBest.Child.Star, 'BOTTOM', 0, 30)
	container:SetPoint('LEFT', ChallengesFrame, 'LEFT', 40, 0)
	Mod.Container = container

	local frame = makePanel(container, 206, Addon.Locale.scheduleTitle)
	frame:SetHeight(128)
	frame:SetPoint('LEFT')
	Mod.Frame = frame

	local entries = {}
	for i = 1, rowCount do
		local entry = CreateFrame('Frame', nil, frame)
		entry:SetSize(176, 18)

		local text = entry:CreateFontString(nil, 'ARTWORK', 'GameFontNormal')
		text:SetWidth(120)
		text:SetJustifyH('LEFT')
		text:SetWordWrap(false)
		text:SetText(Addon.Locale['scheduleWeek' .. i])
		text:SetPoint('LEFT')
		entry.Text = text

		local affixes = {}
		local prevAffix
		for j = 3, 1, -1 do
			local affix = makeAffix(entry)
			if prevAffix then
				affix:SetPoint('RIGHT', prevAffix, 'LEFT', -4, 0)
			else
				affix:SetPoint('RIGHT')
			end
			prevAffix = affix
			affixes[j] = affix
		end
		entry.Affixes = affixes

		if i == 1 then
			entry:SetPoint('TOP', frame.Line, 'BOTTOM')
		else
			entry:SetPoint('TOP', entries[i - 1], 'BOTTOM')
		end
		entries[i] = entry
	end
	frame.Entries = entries

	local label = frame:CreateFontString(nil, 'ARTWORK', 'GameFontNormal')
	label:SetPoint('TOPLEFT', frame.Line, 'BOTTOMLEFT', 10, 0)
	label:SetPoint('TOPRIGHT', frame.Line, 'BOTTOMRIGHT', -10, 0)
	label:SetJustifyH('CENTER')
	label:SetJustifyV('MIDDLE')
	label:SetHeight(72)
	label:SetWordWrap(true)
	label:SetText('')
	frame.Label = label

	-- Party keystones, deliberately using the same panel/background/typography.
	local party = makePanel(container, 206, 'Party Keystones')
	party:SetHeight(128)
	party:SetPoint('RIGHT', 60, 0)
	Mod.PartyFrame = party

	local partyEntries = {}
	for i = 1, 5 do
		local entry = CreateFrame('Frame', nil, party)
		entry:SetSize(176, 18)
		if i == 1 then
			entry:SetPoint('TOP', party.Line, 'BOTTOM')
		else
			entry:SetPoint('TOP', partyEntries[i - 1], 'BOTTOM')
		end

		local text = entry:CreateFontString(nil, 'ARTWORK', 'GameFontNormal')
		text:SetWidth(82)
		text:SetJustifyH('LEFT')
		text:SetWordWrap(false)
		text:SetPoint('LEFT')
		entry.Text = text

		local key = entry:CreateFontString(nil, 'ARTWORK', 'GameFontNormal')
		key:SetWidth(92)
		key:SetJustifyH('RIGHT')
		key:SetWordWrap(false)
		key:SetPoint('RIGHT')
		entry.Key = key

		partyEntries[i] = entry
	end
	party.Entries = partyEntries

	local empty = party:CreateFontString(nil, 'ARTWORK', 'GameFontNormal')
	empty:SetPoint('TOPLEFT', party.Line, 'BOTTOMLEFT', 10, -4)
	empty:SetPoint('TOPRIGHT', party.Line, 'BOTTOMRIGHT', -10, -4)
	empty:SetJustifyH('CENTER')
	empty:SetText('No party members')
	party.Empty = empty

	hooksecurefunc('ChallengesFrame_Update', UpdateAffixes)
	UpdateAffixes()
	RequestPartyKeys()
end

function Mod:CheckInventoryKeystone()
	local foundWeek
	local best = FindBestKeystone()
	if best then
		-- A level 7+ key carries the current affix pair and can correct the
		-- calculated rotation when the client exposes those fields.
		for container = BACKPACK_CONTAINER, NUM_BAG_SLOTS do
			local slots = GetContainerNumSlots(container)
			for slot = 1, slots do
				local _, _, _, _, _, _, slotLink = GetContainerItemInfo(container, slot)
				local itemString = slotLink and slotLink:match('|Hkeystone:([0-9:]+)|h')
				if itemString then
					local info = { strsplit(':', itemString) }
					local mapLevel = tonumber(info[2])
					if mapLevel and mapLevel >= 7 then
						local affix1, affix2 = tonumber(info[3]), tonumber(info[4])
						for index, affixes in ipairs(affixSchedule) do
							if affix1 == affixes[1] and affix2 == affixes[2] then
								foundWeek = index
							end
						end
					end
				end
			end
		end
	end
	currentWeek = foundWeek or GetRotationWeek()
	requestKeystoneCheck = false
end

function Mod:BAG_UPDATE()
	requestKeystoneCheck = true
	if Mod.PartyFrame then
		SendOwnKeystone()
		UpdateAffixes()
	end
end

function Mod:GROUP_ROSTER_UPDATE()
	UpdatePartyRows()
	RequestPartyKeys()
end

function Mod:CHAT_MSG_ADDON(prefix, message, channel, sender)
	if prefix ~= PARTY_PREFIX or channel ~= 'PARTY' then return end
	if sender == GetPlayerName() then return end

	if message == REQUEST then
		SendOwnKeystone()
		return
	end

	local kind, mapID, level = strsplit(':', message)
	if kind == RESPONSE then
		mapID, level = tonumber(mapID), tonumber(level)
		local shortSender = sender:match('^([^%-]+)') or sender
		if mapID and level then
			partyKeys[sender] = { mapID = mapID, level = level, hasAddon = true }
			partyKeys[shortSender] = partyKeys[sender]
		end
		UpdatePartyRows()
	end
end

function Mod:Startup()
	self:RegisterAddOnLoaded('Blizzard_ChallengesUI')
	self:RegisterEvent('BAG_UPDATE')
	self:RegisterEvent('GROUP_ROSTER_UPDATE')
	self:RegisterEvent('CHAT_MSG_ADDON')
	RegisterAddonMessagePrefix(PARTY_PREFIX)
	requestKeystoneCheck = true
end
